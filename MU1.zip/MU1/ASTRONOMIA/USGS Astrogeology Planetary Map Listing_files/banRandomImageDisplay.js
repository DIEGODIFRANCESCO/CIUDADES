
  // SCRIPT:   Random Banner Display
  // Filename: banRandomImageDisplay.js
  // Purpose:  manage the random choosing of an
  //           image for banner.
  //           Slide-show capability included.
  //           Intended for banner images, but
  //           could be customized for any image display.
  //           Duplicated from bgRandomImageDisplay.js
  //           to configure specifically for main page banners.
  //
  // Author:   Deborah Lee Soltesz, USGS, 10/2001

  // to allow "next/previous" buttons to work properly, all images in
  // set should be the same width and height
  //



    // array indices
    banFilename = 0 ;
    banWidth    = 1 ;
    banHeight   = 2 ;
    banComment  = 3 ;

    // customize: edit path
    banBaseURL = "/assets/banners/" ;

    // customize: list images to be used in the script
    banArr = new Array (
        new Array ("earth01.jpg",   "600", "104", "Earth"),
        new Array ("earth02.jpg",   "600", "104", "Earth"),
        new Array ("earth03.jpg",   "600", "104", "Earth"),
        new Array ("jupiter01.jpg", "600", "104", "Jupiter"),
        new Array ("mars01.jpg",    "600", "104", "Mars"),
        new Array ("mercury01.jpg", "600", "104", "Mercury"),
        new Array ("moon01.jpg",    "600", "104", "The Earth's Moon"),
        new Array ("neptune01.jpg", "600", "104", "Neptune"),
        new Array ("neptune02.jpg", "600", "104", "Neptune"),
        new Array ("saturn01.jpg",  "600", "104", "Saturn"),
        new Array ("saturn02.jpg",  "600", "104", "Saturn"),
        new Array ("solar01.jpg",   "600", "104", "Solar"),
        new Array ("uranus01.jpg",  "600", "104", "Uranus"),
        new Array ("uranus02.jpg",  "600", "104", "Uranus"),
        new Array ("venus01.jpg",   "600", "104", "Venus")
    ) ;
    numbanImages = banArr.length ;

    randomNum = Math.floor(Math.random() * numbanImages) ;

    // writes the image width
    function writeBanWidth () {
      document.write(banArr[randomNum][banWidth]) ;
    }

    // writes the image height
    function writeBanHeight () {
      document.write(banArr[randomNum][banHeight]) ;
    }

    // write out the path and filename to the chosen image
    function writeBanPathAndFilename () {
      document.write(banBaseURL + banArr[randomNum][banFilename]) ;
    }

    // write out the chosen image's comment
    function writeBanComment () {
      document.write(banArr[randomNum][banComment]) ;
    }

    // display next image in list in image tag named 'imgName'
    function nextBanImage (imgName) {
      randomNum = (randomNum + 1) % numbanImages ;
      document.images[imgName].src = banBaseURL + banArr[randomNum][banFilename] ;
    }

    // display previous image in list in image tag named 'imgName'
    function prevBanImage (imgName) {
      randomNum = (randomNum + numbanImages - 1) % numbanImages ;
      document.images[imgName].src = banBaseURL + banArr[randomNum][banFilename] ;
    }

    // change specified image tag named 'imgName' to chosen image
    function pickBanImage (imgName) {
      document.images[imgName].src = banBaseURL + banArr[randomNum][banFilename] ;
    }



