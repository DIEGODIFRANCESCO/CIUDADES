

var bName = navigator.appName;
 var bVer = parseInt(navigator.appVersion);
 var NS6 = (bName == "Netscape" && bVer >= 5);
 var NS4 = (bName == "Netscape" && bVer >= 4 && bVer < 5);
 var IE4 = (bName == "Microsoft Internet Explorer" && bVer >= 4);
 var NS3 = (bName == "Netscape" && bVer < 4);
 var IE3 = (bName == "Microsoft Internet Explorer" && bVer < 4);
 window.onerror = null;
 var menuActive = 0
 var menuOn = 0
 var onLayer
 var timeOn = null // LAYER SWITCHING CODE
 var newsIndex = Math.floor(Math.random()*(news.length-1));     // for showing news

 var maxLines = 8;     // how many lines fit in the news box
 var lineLen = 30;    // length of line
 
 if (NS4 || IE4 || NS6) {
	 if (navigator.appName == "Netscape" && !document.getElementById){  // Netscape 4
	 layerStyleRef="layer.";
	 layerRef="document.layers";
	 styleSwitch="";
	 layerVis="show";
	 layerHid="hide";
	 }
	 else if (!document.all && document.getElementById) {    // Netscape 6
	 layerStyleRef="layer.style.";
	 layerRef="document.getElementById";
	 styleSwitch=".style";
	 layerVis="visible";
	 layerHid="hidden";
	 }
	 else {                        // IE
	 layerStyleRef="layer.style.";
	 layerRef="document.all";
	 styleSwitch=".style";
	 layerVis="visible";
	 layerHid="hidden";
	 }
 }
 
 
function showNews() {
    var lines = 0;
    var newslayer;
    var item;
    var item1;
    var text = '<table border=0 cellspacing=5 width=209 height=116>';
   
 //   while ( newsIndex < news.length ) {
    
        item = news[newsIndex][1];
  //      item1 = item.replace(/<[^>]+>/g,"");

  //     lines += Math.ceil(item1.length/lineLen) + 1;

 //      if (lines > maxLines ) {
 //         break;
 //       }
       text += "<tr><td width=209>" + item + "</td></tr>";
       newsIndex++;
 //   }
    
    text += "</table>";
   // alert(text);
    
    if(document.layers){
        //thisbrowser="NN4";
       newslayer = document.layers["news"];
       newslayer.document.open();
       newslayer.document.write(text);
       newslayer.document.close();
    }
    if(document.all){
       //thisbrowser="ie"
       newslayer = document.all["news"];
       newslayer.innerHTML=text;
    }
    if(!document.all && document.getElementById){
        //thisbrowser="NN6";
        newslayer = document.getElementById("news");
        newslayer.innerHTML =text;
    }

    if (newsIndex >= news.length-1) newsIndex = 0;

    setTimeout("showNews()",6000)
}          
 
 function wb_onclick() {
wb = window.open('http://www.windows.ucar.edu/php/workbook/WBentry_beta.php', 'workbook',
 'scrollbars,toolbar,menubar,resizable,location,width=750,height=600,innerWidth=750,innerHeight=600,left=0,top=0'); 
wb.focus();
wb.opener = self;
}

 function shLayer(layerName){
 //img = getImage("planets_space");
 //x = getImagePageLeft(img);
 //y = getImagePageTop(img);
 Top = 520  ; // LAYER TOP POSITION
 Left = 65  ; // LAYER LEFT POSITION
 document.jupiterA.src = "/images_home/jupiterB_sp.jpg";
if (NS4 || IE4 || NS6) {
 if (timeOn != null) {
 clearTimeout(timeOn)
 //hideLayer(onLayer)
 }
 if (NS4 || IE4) {
 eval(layerRef+'["'+layerName+'"]'+styleSwitch+'.visibility="'+layerVis+'"');
 eval(layerRef+'["'+layerName+'"]'+styleSwitch+'.top="'+Top+'"');
 eval(layerRef+'["'+layerName+'"]'+styleSwitch+'.left="'+Left+'"');
 } 
 if (NS6) {
 eval(layerRef+'("'+layerName+'")'+styleSwitch+'.visibility="'+layerVis+'"');
 eval(layerRef+'("'+layerName+'")'+styleSwitch+'.top="'+Top+'"');
 eval(layerRef+'("'+layerName+'")'+styleSwitch+'.left="'+Left+'"');
 } 
 onLayer = layerName
 }

}// HIDE MENU
function hideLayer(layerName){

 if (menuActive == 0) {
 if (NS4 || IE4) {
 eval(layerRef+'["'+layerName+'"]'+styleSwitch+'.visibility="'+layerHid+'"');
 }
 if (NS6) {
 eval(layerRef+'("'+layerName+'")'+styleSwitch+'.visibility="'+layerHid+'"');
 }
 document.jupiterA.src = "/images_home/jupiterA.jpg";
 }
}// TIMER FOR BUTTON MOUSE OUT
function btnTimer() {
 timeOn = setTimeout("btnOut()",1000)
}// BUTTON MOUSE OUT
function btnOut(layerName) {
//alert("menuactive="+menuActive);
 if (menuActive == 0) {
 hideLayer(onLayer)
 }
}// MENU MOUSE OVER 
function menuOver() {
 clearTimeout(timeOn)
 menuActive = 1
}// MENU MOUSE OUT 
function menuOut() {
 menuActive = 0 
 //alert("menuactive1="+menuActive+" onlayer="+onLayer);
 timeOn = setTimeout("hideLayer(onLayer)", 400)
 }
 
 function quick_search() {
    var input = document.search_form.search.value;
    var level;
    if ( location.search ) {
      var edu = location.search.match(/edu=(\w+)/);
      if ( edu ) {
        level = edu[1];
      }
    }
    else {
        level = "mid";
    }
    var url = "http://www.windows.ucar.edu/cgi-bin/search_index_sp.cgi?QUERY=edu=" + level +
     "&SEARCH_TYPE=phrase&USER_LEVEL=" + level + "&INPUT_STRING=" +
    input + "&SEARCH_DIR=&science=1&arts_and_humanities=1&activities_and_games=1&ask_a_scientist=1&tours=1&pictures=1";
    location.href = url;
 }

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
