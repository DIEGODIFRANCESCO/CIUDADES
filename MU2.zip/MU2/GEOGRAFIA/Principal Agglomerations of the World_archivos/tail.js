testHash()

var param = window.location.hash
if ((param != null) && (param.length >= 2))
  window.setInterval("testHash()",500);
