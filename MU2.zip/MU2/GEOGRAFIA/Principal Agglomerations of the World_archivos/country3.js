a = 'e'
actID = -1
appletReady = -1
globNum = true
oldBackground = 'buttonface'
diagramReady = -1
imD = new Image(); imD.src="diagr.gif"
oldHash = ''
namesNumbered = 's'

function getActId () {
  return actID
}

function head_e() {
  document.writeln('<IFRAME class="menu" scrolling="no" frameborder="0" src="head_e.html"></IFRAME>')
}

function head_d() {
  document.writeln('<IFRAME class="menu" scrolling="no" frameborder="0" src="head_d.html"></IFRAME>')
}

function testHash() {
  var param = window.location.hash
  if ((param != null) && (param.length >= 2))
    if (param != oldHash) {
      oldHash = param
      var id = param.substr(2,param.length-2)
      showID(id);
    }
}

function show_map(datei,country,lang,maxscale,minscale,scale,viewwidth,viewheight,provinces) {
  var param = window.location.hash
  if ((param != null) && (param.length >= 2))
    return;
  document.writeln('<APPLET mayscript codebase="java" code="showmap/ShowCountryMapInFrame.class" archive="showcitymap.jar" name="ShowMap" width="0" height="0" vspace="0" hspace="0">')
  document.writeln('<PARAM name="country" value="'+country+'">')
  document.writeln('<PARAM name="url" value="Daten/'+datei+'.zip">')
  document.writeln('<PARAM name="maxscale" value="'+maxscale+'">')
  document.writeln('<PARAM name="minscale" value="'+minscale+'">')
  document.writeln('<PARAM name="scale" value="'+scale+'">')
  document.writeln('<PARAM name="viewwidth" value="'+viewwidth+'">')
  document.writeln('<PARAM name="viewheight" value="'+viewheight+'">')
  document.writeln('<PARAM name="provinces" value="'+provinces+'">')
  document.writeln('<PARAM name="language" value="'+lang+'">')
  document.writeln('<PARAM name="browser" value="'+navigator.appName+'">')
  document.writeln('<PARAM name="agent" value="'+navigator.userAgent+'">')
  document.writeln('</APPLET>')
}


function load_diagram(country,lang) {
  document.writeln('<APPLET mayscript codebase="java" code="diagram/DiagramApplet.class" archive="diagram.jar" name="diagram" width="0" height="0" vspace="0" hspace="0">')
  document.writeln('<PARAM name="country" value="'+country+'">')
  document.writeln('<PARAM name="language" value="'+lang+'">')
  document.writeln('<PARAM name="browser" value="'+navigator.appName+'">')
  document.writeln('<PARAM name="agent" value="'+navigator.userAgent+'">')
  document.writeln('</APPLET>')
}

function sym(id) {
  if (id != actID) {
    if (actID >= 0) {
      var cell = document.getElementById ("i"+actID);
      if (cell != null)
        cell.style.backgroundColor = oldBackground
    }
    actID = id
    if (actID >= 0) {
      var cell = document.getElementById ("i"+actID);
      if (cell != null) {
        oldBackground = cell.style.backgroundColor
        cell.style.backgroundColor = 'red'
      }
      else
        actID = -1
    }
  }
  if ((appletReady == 1) && (diagramReady == 0)) {
    document.ShowMap.activateDiagram()
    diagramReady = 1
  }
  if (appletReady == 1)
    document.ShowMap.movePosByApplet(id)
}

function sg(id) {
  showID(id)
  if (appletReady == 1)
    document.ShowMap.movePosByApplet(id)
}

function go(r) {
  location.href = r
}

function showPage(pre,select,post) {
  if (select.selectedIndex>0)
    window.location.href=pre+select.options[select.selectedIndex].value+post
}

function showID (newActID) {
  if (newActID != actID) {
    if (actID >= 0) {
      var cell = document.getElementById ("i"+actID);
      if (cell != null)
        cell.style.backgroundColor = oldBackground
    }
    actID = newActID
    if (actID >= 0) {
      var cell = document.getElementById ("i"+actID);
      if (cell != null) {
        oldBackground = cell.style.backgroundColor
        cell.style.backgroundColor = 'red'
        cell.scrollIntoView()
      }
      else
        actID = -1
    }
  }
  if ((appletReady == 1) && (diagramReady == 0)) {
    document.ShowMap.activateDiagram()
    diagramReady = 1
  }
}

function showHelp (langID) {
  if (langID == 1)
    window.open('info/appletinfo_e.html','nw','directories=no,location=no,menubar=no,status=no,scrollbars=yes,resizable=yes')
  else
    window.open('info/appletinfo_e.html','nw','directories=no,location=no,menubar=no,status=no,scrollbars=yes,resizable=yes')
}

function setAppletReady () {
  appletReady = 1
}

function cellValue (tableId, index, col) {
  var table = document.getElementById(tableId)
  var cell = table.rows[index].cells[col]
  return cell.innerHTML;
}

function colNum (tableId) {
  var table = document.getElementById(tableId)
  var cells = table.rows[1].cells
  return ""+cells.length
}

function rowNum (tableId) {
  var table = document.getElementById(tableId)
  return ""+table.rows.length
}

function value (cell, num) {
  if (num == true) {
    txt = cell.innerHTML.toUpperCase();
    var pos = txt.indexOf("<A");
    if (pos >= 0)
      return 0;
    txt1 = "0";
    for (var i=0; i<txt.length; i++) {
      ch = txt.charAt(i);
      if ((ch >= '0') && (ch <= '9'))
        txt1 += String.fromCharCode(txt.charCodeAt(i));
    }
    return parseInt(txt1,10);
  }
  else {
    if (cell.firstChild == null)
      txt = cell.innerHTML.toUpperCase();
    else if (cell.firstChild.nodeName == "A")
      txt = cell.firstChild.firstChild.nodeValue.toUpperCase();
    else
      txt = cell.innerHTML.toUpperCase();
    txt1 = "";
    for (var i=0; i<txt.length; i++) {
      ch = txt.charAt(i);
      if ((ch != "'") && (ch != ' ') && (ch != '-'))
        txt1 += String.fromCharCode(txt.charCodeAt(i));
    }
    return txt1
  }
}

function Row (value, row) {
  this.value = value
  this.row = row
}

function compare(a, b) {
  if (globNum) {
    var diff = b.value-a.value;
    if (diff != 0)
      return diff;
    else
      return a.row.getAttribute('ordNum')-b.row.getAttribute('ordNum')
  }
  if (a.value < b.value)
    return -1;
  else if (a.value == b.value)
    return a.row.getAttribute('ordNum')-b.row.getAttribute('ordNum')
  return 1
}

function sort (id, column, num, ign) {
  var table = document.getElementById(id);
  if (table == null)
    return;
  var tableBody = table.firstChild;
  if (tableBody.nodeName.toUpperCase() != "TBODY")
    tableBody = table.childNodes[1];
  if (tableBody.nodeName.toUpperCase() != "TBODY") {
    alert("For this browser, sorting is not supported!");
    return;
  }
  if ((namesNumbered != 'f') && (namesNumbered != id)) {
    for (var i=0; i<table.rows.length; i++)
      table.rows[i].setAttribute('ordNum',i);
    if (namesNumbered == 's')
      namesNumbered = id;
    else
      namesNumbered = 'f';
  }
  globNum = num;
  var data = new Array();
  var max = table.rows.length-ign;
  if (column > 1)
    for (var i=1; i<max; i++)
      data[i-1] = new Row(value(table.rows[i].cells[column],num),table.rows[i]);
  else
    for (var i=1; i<max; i++)
      data[i-1] = new Row(Number(table.rows[i].getAttribute('ordNum')),table.rows[i]);
  data.sort(compare)
  for (var i=0; i<max-1; i++)
    tableBody.appendChild(data[i].row);
  if (ign > 0)
    for (var i=1; i<=ign; i++)
      tableBody.appendChild(table.rows[1]);
}

function show_diagram(id,minusRows) {
  if (diagramReady < 0)
    return;
  var table = document.getElementById(id);
  if (table == null)
    return;
  document.diagram.openDiagram(id,table.rows,minusRows)
}

function showDiagramHelp (lang) {
   if (lang == 'D')
     window.open('info/diagraminfo_e.html','nw','directories=no,location=no,menubar=no,status=no,scrollbars=yes,resizable=yes')
   else
     window.open('info/diagraminfo_e.html','nw','directories=no,location=no,menubar=no,status=no,scrollbars=yes,resizable=yes')
}

function setDiagramAppletReady () {
  var butt = document.getElementById("CityDiagramButton");
  if (butt != null) {
    butt.disabled = false
    diagramReady = 0
  }
  var butt = document.getElementById('ProvDiagramButton');
  if (butt != null) {
    butt.disabled = false
    diagramReady = 0
  }
  var b1 = document.getElementById("pdb");
  if (b1 != null) {
    b1.src = imD.src
    diagramReady = 0
  }
  var b2 = document.getElementById("cdb");
  if (b2 != null) {
    b2.src = imD.src
    diagramReady = 0
  }
}

function showObjectDiagram(id,type) {
  var tableId = (type.charAt(0)=='C') ? 'ts' : 'tl';
  var table = document.getElementById(tableId)
  if (table == null)
    return;
  focus()
  document.diagram.openObjectDiagram(tableId,table.rows,id)
}
